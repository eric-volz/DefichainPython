
class SchemeIDMainnet:
    MIN1000: str = "MIN1000"
    MIN500: str = "MIN500"
    MIN350: str = "MIN350"
    MIN200: str = "MIN200"
    MIN175: str = "MIN175"
    MIN150: str = "MIN150"

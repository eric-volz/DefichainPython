class Spv:
    def __init__(self, node):
        self._node = node

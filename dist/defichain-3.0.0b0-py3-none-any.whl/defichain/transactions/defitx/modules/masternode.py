from .basedefitx import BaseDefiTx


class CreateMasternode(BaseDefiTx):
    """TODO: MVP"""
    pass


class ResignMasternode(BaseDefiTx):
    pass


class UpdateMasternode(BaseDefiTx):
    """TODO: MVP"""
    pass


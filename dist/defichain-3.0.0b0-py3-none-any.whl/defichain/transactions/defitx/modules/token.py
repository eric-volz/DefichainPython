from .basedefitx import BaseDefiTx


class TokenMint(BaseDefiTx):
    pass


class TokenCreate(BaseDefiTx):
    pass


class TokenUpdate(BaseDefiTx):
    pass


class TokenUpdateAny(BaseDefiTx):
    pass

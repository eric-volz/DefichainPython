class Spv:
    def __init__(self, node):
        self.node = node

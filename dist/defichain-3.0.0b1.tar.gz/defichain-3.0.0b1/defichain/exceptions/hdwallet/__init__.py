# hdwallet exceptions
from defichain.exceptions.hdwallet.DerivationError import DerivationError

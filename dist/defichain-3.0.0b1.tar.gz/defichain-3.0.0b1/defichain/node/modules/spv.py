class Spv:
    """
    Currently not supported.

    Will be added when needed.
    """
    def __init__(self, node):
        self._node = node

# Just to be present: Ocean
from defichain.ocean.modules.address import Address
from defichain.ocean.modules.blocks import Blocks
from defichain.ocean.modules.consortium import Consortium
from defichain.ocean.modules.fee import Fee
from defichain.ocean.modules.governance import Governance
from defichain.ocean.modules.loan import Loan
from defichain.ocean.modules.masternodes import Masternodes
from defichain.ocean.modules.oracles import Oracles
from defichain.ocean.modules.poolpairs import Poolpairs
from defichain.ocean.modules.prices import Prices
from defichain.ocean.modules.rawTx import RawTx
from defichain.ocean.modules.rpc import Rpc
from defichain.ocean.modules.stats import Stats
from defichain.ocean.modules.tokens import Tokens
from defichain.ocean.modules.transactions import Transactions

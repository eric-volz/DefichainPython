from .networks import DefichainMainnet, DefichainTestnet, DefichainRegtest

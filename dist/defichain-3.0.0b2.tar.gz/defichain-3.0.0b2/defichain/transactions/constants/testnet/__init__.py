

class SchemeIDTestnet:
    MIN1000: str = "C1000"
    MIN500: str = "C500"
    MIN350: str = "C350"
    MIN200: str = "C200"
    MIN175: str = "C175"
    MIN150: str = "C150"

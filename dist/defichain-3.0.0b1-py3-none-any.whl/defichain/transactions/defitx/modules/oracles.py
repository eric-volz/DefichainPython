from .basedefitx import BaseDefiTx


class AppointOracle(BaseDefiTx):
    pass


class RemoveOracle(BaseDefiTx):
    pass


class UpdateOracle(BaseDefiTx):
    pass


class SetOracleData(BaseDefiTx):
    pass

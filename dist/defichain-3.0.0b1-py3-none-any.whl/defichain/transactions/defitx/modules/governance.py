from .basedefitx import BaseDefiTx


class SetGovernance(BaseDefiTx):
    pass


class SetGovernanceHeight(BaseDefiTx):
    pass


class CreateCfp(BaseDefiTx):
    pass


class CreateVoc(BaseDefiTx):
    pass


class Vote(BaseDefiTx):
    """TODO: MVP"""
    pass

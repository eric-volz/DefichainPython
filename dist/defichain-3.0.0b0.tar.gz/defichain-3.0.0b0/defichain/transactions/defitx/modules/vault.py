from .basedefitx import BaseDefiTx


class CreateVault(BaseDefiTx):
    """TODO: MVP"""
    pass


class UpdateVault(BaseDefiTx):
    pass


class DepositToVault(BaseDefiTx):
    """TODO: MVP"""
    pass


class WithdrawFromVault(BaseDefiTx):
    """TODO: MVP"""
    pass


class CloseVault(BaseDefiTx):
    pass


class PlaceAuctionBid(BaseDefiTx):
    pass
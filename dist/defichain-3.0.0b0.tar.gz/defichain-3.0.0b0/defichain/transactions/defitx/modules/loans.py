from .basedefitx import BaseDefiTx


class SetLoanScheme(BaseDefiTx):
    pass


class DestroyLoanScheme(BaseDefiTx):
    pass


class SetDefaultLoanScheme(BaseDefiTx):
    pass


class SetCollateralToken(BaseDefiTx):
    pass


class SetLoanToken(BaseDefiTx):
    pass


class UpdateLoanToken(BaseDefiTx):
    pass


class TakeLoan(BaseDefiTx):
    pass


class PaybackLoan(BaseDefiTx):
    pass


class PaybackLoanV2(BaseDefiTx):
    pass